//Step definitions class file
package stepDefinitions;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.Before;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import pageObjects.Login;
import pageObjects.shopPortalObjs;
import pageObjects.General;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import pageObjects.CommonFunc;

@SuppressWarnings("ALL")
public class Steps {
    private WebDriver driver;
    private Actions action;
    private shopPortalObjs shopObjs;
    private General general;
    private CommonFunc func;
    private Login login;

//Before hook to setup the ChromeDriver
    @Before
    public void setUp(Scenario scenario) throws IOException {
        try
        {System.out.println("-------------------------------------------------------");
        System.out.println("Starting - " + scenario.getName());
        System.out.println("--------------------------------------------------------");
        func = new CommonFunc(driver);
        func.SetupChrome();
        }
        catch (Exception e)
        {
            func.captureScreenshot("t",".pdf");
            throw  new Error(e);
        }
    }

/* close the browser */
   @After
    public void tearDown(Scenario scenario) {
       System.out.println("-----------------------------------------------------------------------");
       System.out.println("Scenario:"+ scenario.getName() +"             " + " Status - " + scenario.getStatus());
       System.out.println("-----------------------------------------------------------------------");
       if (scenario.isFailed()) {
           final byte[] screenshot = ((TakesScreenshot) driver)
                   .getScreenshotAs(OutputType.BYTES);
           scenario.embed(screenshot, "image/png"); //stick it in the report
       }

       //close all browsers
       driver.quit();
   }

    @Given("Registered user is on the Home page {string}")
    public void registered_user_is_on_the_Home_page(String baseUrl) {
        try {
            //Launch the Browser and open the below url
            driver = new ChromeDriver();
            driver.get(baseUrl);
            // maximize the browser window
            driver.manage().window().maximize();
            driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
            action = new Actions(driver);
            shopObjs = new shopPortalObjs(driver);
            general = new General(driver);
        }
        catch (Exception e)
        {
            throw  new Error(e);
        }

    }

    @When("I Login to the shopping Website with email address {string} and password {string}")
    public void i_Login_to_the_shopping_Website_with_email_address_and_password(String email, String password) {
        try
        {
            general.Login(email, password);
         }
        catch (Exception e)
        {
            throw  new Error(e);
        }
    }
    @When("Add items to cart and perform logout")
    public void add_items_to_cart_and_perform_logout() {
        try
        {
            general.SelectCasualDress();
            general.sltEvengDress();
            general.SelectDressesBtn();

            //Re-login code has been commented due to issues with Cart button - once i logout from the application
            //After re-login Cart will be empty

            // general.SignOut();
            general.ValidateCart();
}
        catch (Exception e)
        {
            throw  new Error(e);
        }
 }
    @When("re_login to website with email {string}and password {string} then place order")
    public void re_login_to_website_with_email_and_Password_then_place_order(String email, String password) {
      try
      {
          //Re-login code has been commented due to issues with Cart button - once i logout from the application
          //After re-login Cart will be empty

          //general.Login(email,password);
          //Proceed to checkout button in summary page
          general.ClickChkOutButton();
          //Proceed to checkout button in address page
          general.ClickChkOutButton();
          //Perform final Checkout
          general.ClickFinalChkOutBtn();
          //Pay by check
          general.PayByCheck();
          //Confirm order
          general.ConfirmOrder();
      }
      catch (Exception e)
      {
          throw  new Error(e);
      }

    }

    @Then("Verify order")
    public void verify_order() {
        try {
            //Verify Order
            general.ValidateOrder();
            //Logout from application
            general.SelectDressesBtn();
            general.SignOut();
        }
        catch (Exception e)
        {
            throw  new Error(e);
        }
    }

}