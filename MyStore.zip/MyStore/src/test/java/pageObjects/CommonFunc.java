package pageObjects;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

//Common Functions
public class CommonFunc {
    private WebDriver driver;

    public CommonFunc(WebDriver driver) { this.driver = driver;

    }

    public CommonFunc() {

    }

    public void SetupChrome()
    {
        String path = System.getProperty("user.dir");   // return project folder path
        String strDriverPath = path + "\\src\\main\\resources\\Drivers\\chromedriver.exe";   // return driver folder path
        System.setProperty("webdriver.chrome.driver", strDriverPath);
    }

    public void captureScreenshot(String fileName, String s) throws IOException
    {
        // Take the screenshot and store as file format
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

        // Open the current date and time
        String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
        String path = System.getProperty("user.dir");   // return project folder path
        String strFilePath = path + "\\src\\target\\MyDirectory";  // return driver folder path
        //Copy the screenshot on the desire location with different name using current date and time
        FileUtils.copyFile(scrFile, new File(strFilePath  + fileName +"."+timestamp+s));

    }
}
