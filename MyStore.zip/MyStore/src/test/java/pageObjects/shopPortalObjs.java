package pageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Page objects of shopping portal pages except login page
 */
@SuppressWarnings("ALL")
public class shopPortalObjs {
    By btnDresses = 	By.xpath("//*[@id='block_top_menu']/ul/li[2]");
    By btnCasualDress= By.linkText("Casual Dresses");
    By btnCasualDress1= By.xpath("//*[@id='center_column']/ul/li[1]");
    By btnAddToCart= By.xpath("//span[contains(text(),'Add to cart')]");
    By btnContinue= By.xpath("//span[@title='Continue shopping']");
    By btnSumDresses = By.linkText("Summer Dresses");
    By btnSumDress1 = By.xpath("//*[@id='center_column']/ul/li[1]");
    By btnCheckOut = By.xpath("//*[contains(text(), 'Proceed to checkout')]");
    By btnChkOut1 = By.xpath("//*[text()='Proceed to checkout']");
    By btnCheck= By.xpath("//input[@type='checkbox']");
    By btnPayByChk = By.xpath("//a[@title='Pay by check.']");
    By btnProChk = By.xpath("//button[@type='submit']/span[contains(text(),'Proceed to checkout')]");
    By btnConfirmOrder= By.xpath("//button[@type='submit']/span[contains(text(),'I confirm my order')]");
    By StrSuccessMsg = By.xpath("//p[contains(text(), 'Your order on My Store is complete')]");
    By btnCart = By.xpath("//b[text()='Cart']");
    By StrCartVal = By.className("ajax_cart_quantity");
    By btnCheckOutMain = By.id("button_order_cart");

    public shopPortalObjs(WebDriver driver) {
    }
}