package pageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Page objects of login page
 */
@SuppressWarnings("ALL")
public class Login {
    By emailId = By.id("email");
    By passWd= By.name("passwd");
    By btnLogin= By.id("SubmitLogin");
    By btnSign_in= By.xpath("//*[@title='Log in to your customer account']");
    By btnSign_out = By.xpath("//a[@title='Log me out']");

    public Login(WebDriver driver) {

    }
}
