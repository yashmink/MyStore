package pageObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//Application related functions
public class General{

    private WebDriver driver;
    private Actions action;
    private shopPortalObjs  shopObjs;
    private Login login;

    public General(WebDriver driver) {
        this.driver = driver;
       action = new Actions(this.driver);
       shopObjs = new shopPortalObjs(this.driver);
       login = new Login(this.driver);
   }

//Login Function
   public void Login(String email, String password){
       driver.findElement(login.btnSign_in).click();
       driver.findElement(login.emailId).clear();
       driver.findElement(login.emailId).sendKeys(email);
       driver.findElement(login.passWd).clear();
       driver.findElement(login.passWd).sendKeys(password);
       driver.findElement(login.btnLogin).click();

   }

//Logout function
    public void SignOut()
    {
        driver.findElement(login.btnSign_out).click();
    }

//function to add casual dresses
    public void SelectCasualDress() {
        //Adding Casual dress to the cart
        WebElement btnDress = driver.findElement(shopObjs.btnDresses);
        action.moveToElement(btnDress).build().perform();
        action.click(btnDress).build().perform();
        action.sendKeys(Keys.PAGE_DOWN).build().perform();
        WebElement btnCasual = driver.findElement(shopObjs.btnCasualDress);
        action.moveToElement(btnCasual).perform();
        action.click(btnCasual).build().perform();
        WebElement btnDress1 = driver.findElement(shopObjs.btnCasualDress1);
        action.moveToElement(btnDress1).perform();
        action.doubleClick(btnDress1).build().perform();
        WebElement btnCart = driver.findElement(shopObjs.btnAddToCart);
        action.moveToElement(btnCart).perform();
        action.click(btnCart).build().perform();
        WebElement btnCont = driver.findElement(shopObjs.btnContinue);
        WebElement element = (new WebDriverWait(driver, 30)).until(ExpectedConditions.elementToBeClickable(btnCont));
        action.moveToElement(element)
                .click()
                .perform();
    }

// function to select dresses button
    public void SelectDressesBtn()
    {
        WebElement btnDress = driver.findElement(shopObjs.btnDresses);
        action.moveToElement(btnDress).build().perform();
        action.click(btnDress).build().perform();
    }

// function to add evening dresses
    public void sltEvengDress()
    {
        //Adding summer dress to the cart
        WebElement btnDress3 = driver.findElement(shopObjs.btnDresses);
        action.moveToElement(btnDress3).build().perform();
        action.click(btnDress3).build().perform();
        action.sendKeys(Keys.PAGE_DOWN).build().perform();
        WebElement btnSumDress = driver.findElement(shopObjs.btnSumDresses);
        action.moveToElement(btnSumDress).build().perform();
        action.click(btnSumDress).build().perform();
        WebElement btnSum = driver.findElement(shopObjs.btnSumDress1);
        action.moveToElement(btnSum).perform();
        action.click(btnSum).build().perform();
        WebElement btnCart1 = driver.findElement(shopObjs.btnAddToCart);
        action.moveToElement(btnCart1).perform();
        action.click(btnCart1).build().perform();
    }

//Click Checkout button
    public void ClickChkOutButton()
    {
        WebElement btnChk1 = driver.findElement(shopObjs.btnChkOut1);
        action.moveToElement(btnChk1).perform();
        WebElement btnChk3 = driver.findElement(shopObjs.btnChkOut1);
        action.doubleClick(btnChk3).build().perform();
     }

//Click  final Checkout button
    public void ClickFinalChkOutBtn()
    {
        //Accept terms and conditions
        WebElement btnCh1 = driver.findElement(shopObjs.btnCheck);
        btnCh1.click();
        action.sendKeys(Keys.PAGE_DOWN).build().perform();
        //Click Proceed to checkout button in shipping page
        WebElement btnChk7 = driver.findElement(shopObjs.btnProChk);
        action.moveToElement(btnChk7).perform();
        WebElement btnChk8 = driver.findElement(shopObjs.btnProChk);
        action.doubleClick(btnChk8).build().perform();

    }

//Pay by check
    public void PayByCheck()
    {
        WebElement clickChkBtn= driver.findElement(shopObjs.btnPayByChk);
        clickChkBtn.click();
    }

//Confirm order
    public void ConfirmOrder()
    {
        WebElement btnConfirm= driver.findElement(shopObjs.btnConfirmOrder);
        btnConfirm.click();

    }

 //Validate Order
    public void ValidateOrder()
    {
        WebElement StrMsg= driver.findElement(shopObjs.StrSuccessMsg);
        String actualTitle = StrMsg.getText();
        String expectedTitle = "Your order on My Store is complete.";
        action.sendKeys(Keys.PAGE_UP).build().perform();
        action.sendKeys(Keys.PAGE_DOWN).build().perform();
        //Validate Successful message
        if (expectedTitle.startsWith(actualTitle)) {
            System.out.println("----------------------- Order placed successfully-------------------------");

        } else {
            System.out.println("-------------------------Order unsuccessful-------------------------------");
        }
    }

//Validate Items in cart

    public void ValidateCart() {
        //Get the count of items in Cart
        String strVal = driver.findElement(shopObjs.StrCartVal).getText();
        String StrExp = "2";
        if (StrExp.equals(strVal)) {
            System.out.println("-----------------------------------------------");
            System.out.println("---------Items in cart have been validated-----");
            System.out.println("-----------------------------------------------");
            WebElement btnCart1 = driver.findElement(shopObjs.btnCart);
            action.moveToElement(btnCart1).perform();
            action.click(btnCart1).build().perform();
            }
        }
    }
