//Test Runner class created by Yashmin Kondala
package testRunner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@SuppressWarnings("ALL")
@RunWith(Cucumber.class)
@CucumberOptions(features="C://Users//user//IdeaProjects//MyStore//Features//SmokeTest.feature",glue= "stepDefinitions",
plugin = {"pretty","html:target/MyDirectory"},
monochrome = true
)
public class Runner
{

}
